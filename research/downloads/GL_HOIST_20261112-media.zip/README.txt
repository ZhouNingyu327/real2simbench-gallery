Real2SimBench public display media

This package contains the original REF/A/E/V display clips and the public case description. It is not a native GT dataset, a full solver checkpoint or a hidden evaluation configuration.
Video hashes and validation limits are recorded in the included JSON files. Source code and asset license statements are separate.
